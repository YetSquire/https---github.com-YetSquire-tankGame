package src;

public class Constants {
	public static double shellSpeed = 30;
	public static int tankWidth  = 85;
	public static int tankHeight = 50;
	public static int tankSpeed = 10;
	public static int shellSize = 10;
	public static int barrel = 50;
	public static int panelHeight = 800;
	public static int panelWidth = 800;
	public static int shellHP = 1;
	public static int enemyHP = 100;
	public static int tankHP = 400;
}
